﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlyoutPageNavigation
{
    public class ClaseFlyout
    {
        public string titulo { get; set; }

        //public string imagen { get; set; }

        public Type pagina { get; set; }
    }
}

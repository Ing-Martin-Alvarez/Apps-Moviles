﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TabbedPageNavigation
{
    public class Jugador
    {
        public string Nombre { get; set; }
        public string Equipo { get; set; }
        public string Edad { get; set; }
        public string Foto { get; set; }
    }
}
